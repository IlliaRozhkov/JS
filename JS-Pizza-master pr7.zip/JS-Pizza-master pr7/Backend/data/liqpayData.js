const public = 'i99337524173';
const private = 'KWBHvOQMeWJQ8mN437zzcPEpgDO8nnEywgcJXEuj';

exports = { public, private };
